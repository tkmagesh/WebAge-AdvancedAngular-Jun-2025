export type Currency = 'USD' | 'GBP' | 'EUR';
